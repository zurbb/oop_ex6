package oop.ex6.utils;
public class Types {
    public static final String INT ="int";
    public static final String DOUBLE ="double";
    public static final String BOOLEAN ="boolean";
    public static final String CHAR ="char";
    public static final String STRING ="String";

}
